// Tiny inline replacements for the four lucide-react icons the game uses,
// so the app has no icon dependency (same 24x24 stroke style as lucide).
import type { SVGProps } from "react";
const base = (p: SVGProps<SVGSVGElement>) => ({
  xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "none",
  stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const, "aria-hidden": true, ...p,
});
export const Volume2 = (p: SVGProps<SVGSVGElement>) => (
  <svg {...base(p)}><path d="M11 4.7 6.7 9H3v6h3.7l4.3 4.3z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 5.5a9 9 0 0 1 0 13"/></svg>
);
export const VolumeX = (p: SVGProps<SVGSVGElement>) => (
  <svg {...base(p)}><path d="M11 4.7 6.7 9H3v6h3.7l4.3 4.3z"/><path d="m22 9-6 6"/><path d="m16 9 6 6"/></svg>
);
export const Undo2 = (p: SVGProps<SVGSVGElement>) => (
  <svg {...base(p)}><path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/></svg>
);
export const CircleHelp = (p: SVGProps<SVGSVGElement>) => (
  <svg {...base(p)}><circle cx="12" cy="12" r="10"/><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3"/><path d="M12 17h.01"/></svg>
);
