import { createRoot } from "react-dom/client";
import { Game } from "@/components/umlabalaba/Game";

createRoot(document.getElementById("root")!).render(<Game />);
