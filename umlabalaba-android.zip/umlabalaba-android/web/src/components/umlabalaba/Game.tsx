import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { CircleHelp, Undo2, Volume2, VolumeX } from "@/icons";
import { BoardView } from "@/components/umlabalaba/Board";
import { chooseAiAction } from "@/lib/umlabalaba/ai";
import {
  activePlayer,
  freshState,
  hint,
  legalDestinations,
  nameOf,
  reduce,
  removablePoints,
  type Action,
  type GameState,
  type Mode,
} from "@/lib/umlabalaba/machine";
import { opponent, shiftMoves, count, type Player, type PointId } from "@/lib/umlabalaba/rules";
import { isMuted, play, setMuted, unlockAudio } from "@/lib/umlabalaba/sound";

type Screen = "setup" | "toss" | "play";
type Tally = { ivory: number; oxblood: number; draws: number; last: number };

const TALLY_KEY = "umlabalaba-tally";
const MUTE_KEY = "umlabalaba-mute";
const EMPTY_TALLY: Tally = { ivory: 0, oxblood: 0, draws: 0, last: 0 };

function readTally(): Tally {
  if (typeof window === "undefined") return EMPTY_TALLY;
  try {
    const raw = localStorage.getItem(TALLY_KEY);
    if (!raw) return EMPTY_TALLY;
    const parsed = JSON.parse(raw) as Partial<Tally>;
    return {
      ivory: Number(parsed.ivory) || 0,
      oxblood: Number(parsed.oxblood) || 0,
      draws: Number(parsed.draws) || 0,
      last: Number(parsed.last) || 0,
    };
  } catch {
    return EMPTY_TALLY;
  }
}

function phaseLabel(state: GameState): string {
  switch (state.phase) {
    case "ready":
      return "Hand over the phone";
    case "place":
      return "Placing coins";
    case "capture":
    case "take":
      return "Remove a coin";
    case "move":
    case "shift":
      return count(state.board, state.turn) === 3 && state.phase === "move" ? "Jumping" : "Moving";
    case "stuck":
    case "respond":
      return "No move";
    case "over":
      return state.winner == null ? "Drawn" : "Match over";
    default:
      return "";
  }
}

export function Game() {
  const [screen, setScreen] = useState<Screen>("setup");
  const [mode, setMode] = useState<Mode>("hotseat");
  const [human, setHuman] = useState<Player>(0);
  const [names, setNames] = useState<[string, string]>(["Ivory", "Oxblood"]);
  const [starter, setStarter] = useState<Player | null>(null);
  const [state, setState] = useState<GameState>(freshState);
  const [rulesOpen, setRulesOpen] = useState(false);
  const [muted, setMutedState] = useState(false);
  const [tally, setTally] = useState<Tally>(EMPTY_TALLY);
  const ref = useRef(state);
  ref.current = state;
  const matchSeq = useRef(0);

  useEffect(() => {
    setTally(readTally());
    const stored = localStorage.getItem(MUTE_KEY) === "1";
    setMutedState(stored);
    setMuted(stored);
  }, []);

  const act = useCallback((action: Action) => {
    const result = reduce(ref.current, action);
    ref.current = result.state;
    setState(result.state);
    for (const event of result.events) play(event);
  }, []);

  useEffect(() => {
    if (screen !== "play" || rulesOpen) return;
    const snapshot = state;
    if (snapshot.mode !== "cpu") return;
    if (snapshot.phase === "over" || snapshot.phase === "ready") return;
    if (activePlayer(snapshot) === snapshot.human) return;
    const timer = window.setTimeout(() => {
      const live = ref.current;
      if (live.mode !== "cpu" || live.phase === "over" || live.phase === "ready") return;
      if (activePlayer(live) === live.human) return;
      const action = chooseAiAction(live);
      if (action) act(action);
    }, 520);
    return () => window.clearTimeout(timer);
  }, [state, screen, rulesOpen, act]);

  useEffect(() => {
    if (screen !== "play" || state.phase !== "over") return;
    const current = readTally();
    if (current.last === state.matchId) return;
    const next: Tally = { ...current, last: state.matchId };
    if (state.winner == null) next.draws += 1;
    else if (state.winner === 0) next.ivory += 1;
    else next.oxblood += 1;
    localStorage.setItem(TALLY_KEY, JSON.stringify(next));
    setTally(next);
  }, [screen, state.phase, state.matchId, state.winner]);

  function begin(who: Player) {
    matchSeq.current += 1;
    const action: Action = {
      type: "start",
      starter: who,
      mode,
      human,
      names,
      matchId: matchSeq.current,
    };
    const result = reduce(freshState(), action);
    ref.current = result.state;
    setState(result.state);
    setScreen("play");
    setStarter(null);
  }

  function onPoint(id: PointId) {
    const live = ref.current;
    if (live.phase === "place") {
      act({ type: "place", point: id });
      return;
    }
    if (live.phase === "capture") {
      act({ type: "capture", point: id });
      return;
    }
    if (live.phase === "take") {
      act({ type: "take", point: id });
      return;
    }
    if (live.phase === "move" || live.phase === "shift") {
      const actor = activePlayer(live);
      if (live.board[id] === actor) {
        act({ type: "select", point: id });
        return;
      }
      if (live.selected && legalDestinations(live).includes(id)) {
        act(
          live.phase === "move"
            ? { type: "move", from: live.selected, to: id }
            : { type: "shift", from: live.selected, to: id },
        );
      } else {
        play("bad");
      }
    }
  }

  const yours =
    state.mode === "hotseat" || (screen === "play" && activePlayer(state) === state.human);
  const interactive =
    yours &&
    (state.phase === "place" ||
      state.phase === "capture" ||
      state.phase === "move" ||
      state.phase === "shift" ||
      state.phase === "take");
  const thinking =
    screen === "play" &&
    state.mode === "cpu" &&
    state.phase !== "over" &&
    state.phase !== "ready" &&
    activePlayer(state) !== state.human;

  return (
    <main
      className="mx-auto flex min-h-dvh w-full max-w-xl flex-col px-4 py-5"
      onPointerDown={() => unlockAudio()}
    >
      {screen === "setup" && (
        <Setup
          mode={mode}
          human={human}
          names={names}
          tally={tally}
          onMode={setMode}
          onHuman={setHuman}
          onNames={setNames}
          onToss={() => {
            setStarter(null);
            setScreen("toss");
          }}
          onRules={() => setRulesOpen(true)}
        />
      )}
      {screen === "toss" && (
        <Toss
          names={names}
          onLanded={(who) => setStarter(who)}
          starter={starter}
          onBegin={() => starter != null && begin(starter)}
          onBack={() => setScreen("setup")}
        />
      )}
      {screen === "play" && (
        <section className="flex min-h-0 flex-1 flex-col gap-3">
          <header className="flex items-start justify-between gap-3">
            <div>
              <h1 className="font-display text-3xl leading-none text-ink">Umlabalaba</h1>
              <p className="mt-1 text-sm text-muted">{phaseLabel(state)}</p>
            </div>
            <div className="flex gap-2">
              <IconButton
                label={muted ? "Unmute" : "Mute"}
                onClick={() => {
                  const next = !muted;
                  setMutedState(next);
                  setMuted(next);
                  localStorage.setItem(MUTE_KEY, next ? "1" : "0");
                }}
              >
                {muted ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />}
              </IconButton>
              <IconButton
                label="Undo"
                disabled={state.history.length === 0}
                onClick={() => act({ type: "undo" })}
              >
                <Undo2 className="size-5" />
              </IconButton>
              <IconButton label="How to play" onClick={() => setRulesOpen(true)}>
                <CircleHelp className="size-5" />
              </IconButton>
            </div>
          </header>

          <div className="grid grid-cols-2 gap-2">
            <PlayerCard state={state} player={0} />
            <PlayerCard state={state} player={1} />
          </div>

          <div className="board-card aspect-square w-full shrink-0 p-2">
            <BoardView
              board={state.board}
              names={state.names}
              selected={state.selected}
              destinations={legalDestinations(state)}
              removable={removablePoints(state)}
              mill={state.millFlash}
              lastPoint={state.lastPoint}
              interactive={interactive && !rulesOpen}
              onPoint={onPoint}
            />
          </div>

          <div className="flex flex-col gap-2 pb-2" aria-live="polite">
            <p className="min-h-11 text-sm leading-snug text-ink">{thinking ? "Thinking…" : hint(state)}</p>
            {state.phase === "ready" && (
              <ActionButton player={state.gateActor} onClick={() => act({ type: "ready" })}>
                {nameOf(state, state.gateActor)}, I'm ready
              </ActionButton>
            )}
            {state.phase === "stuck" && yours && (
              <ActionButton player={state.turn} onClick={() => act({ type: "ask" })}>
                Ask {nameOf(state, opponent(state.turn))} to make way
              </ActionButton>
            )}
            {state.phase === "respond" && yours && (
              <div className="grid grid-cols-2 gap-2">
                <ActionButton
                  player={opponent(state.turn)}
                  disabled={shiftMoves(state.board, opponent(state.turn), state.turn).length === 0}
                  onClick={() => act({ type: "want-shift" })}
                >
                  Make way
                </ActionButton>
                <button
                  type="button"
                  className="h-12 rounded-2xl bg-ink text-sm font-medium text-card"
                  onClick={() => act({ type: "want-take" })}
                >
                  Take a coin
                </button>
              </div>
            )}
            {state.phase === "over" && (
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  className="h-12 rounded-2xl bg-ochre text-sm font-medium text-card"
                  onClick={() => setScreen("toss")}
                >
                  Toss again
                </button>
                <button
                  type="button"
                  className="h-12 rounded-2xl bg-card text-sm font-medium text-ink"
                  onClick={() => setScreen("setup")}
                >
                  Back
                </button>
              </div>
            )}
          </div>
        </section>
      )}
      {rulesOpen && (
        <Rules
          playing={screen === "play" && state.phase !== "over"}
          onClose={() => setRulesOpen(false)}
          onResign={() => {
            setRulesOpen(false);
            act({ type: "resign" });
          }}
          onAbandon={() => {
            setRulesOpen(false);
            setScreen("setup");
          }}
        />
      )}
    </main>
  );
}

function IconButton({
  label,
  onClick,
  disabled,
  children,
}: {
  label: string;
  onClick: () => void;
  disabled?: boolean;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      disabled={disabled}
      onClick={onClick}
      className="grid size-11 place-items-center rounded-full bg-card text-ink disabled:opacity-40"
    >
      {children}
    </button>
  );
}

function ActionButton({
  player,
  children,
  onClick,
  disabled,
}: {
  player: Player;
  children: ReactNode;
  onClick: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={
        player === 0
          ? "h-12 rounded-2xl border border-brass bg-ivory text-sm font-medium text-ink disabled:opacity-40"
          : "h-12 rounded-2xl bg-oxblood text-sm font-medium text-ivory disabled:opacity-40"
      }
    >
      {children}
    </button>
  );
}

function PlayerCard({ state, player }: { state: GameState; player: Player }) {
  const active = state.phase !== "over" && activePlayer(state) === player;
  const onBoard = count(state.board, player);
  return (
    <div
      className={`rounded-2xl bg-card px-3 py-2 ${active ? "ring-2 ring-ochre" : "ring-1 ring-paper-deep"}`}
    >
      <div className="flex items-center gap-2">
        <span
          className={`size-3 shrink-0 rounded-full ${player === 0 ? "bg-ivory ring-2 ring-brass" : "bg-oxblood"}`}
          aria-hidden
        />
        <p className="truncate font-display text-lg leading-tight text-ink">{nameOf(state, player)}</p>
      </div>
      <p className="mt-1 text-xs text-muted">
        Hand {state.hand[player]} · Board {onBoard} · Lost {state.taken[player]}
      </p>
    </div>
  );
}

function Setup({
  mode,
  human,
  names,
  tally,
  onMode,
  onHuman,
  onNames,
  onToss,
  onRules,
}: {
  mode: Mode;
  human: Player;
  names: [string, string];
  tally: Tally;
  onMode: (mode: Mode) => void;
  onHuman: (player: Player) => void;
  onNames: (names: [string, string]) => void;
  onToss: () => void;
  onRules: () => void;
}) {
  return (
    <section className="flex flex-1 flex-col gap-6">
      <div>
        <p className="text-xs font-medium tracking-widest text-muted uppercase">For two players</p>
        <h1 className="mt-2 font-display text-5xl leading-none text-ink">Umlabalaba</h1>
        <p className="mt-3 max-w-sm text-base leading-relaxed text-muted">
          Twelve coins each, different colours. Place them on the points, then slide. Three in a
          straight line lets you take one of theirs.
        </p>
      </div>

      <p className="text-sm text-muted">
        Ivory {tally.ivory} · Draws {tally.draws} · Oxblood {tally.oxblood}
      </p>

      <div className="flex flex-col gap-3">
        <label className="flex flex-col gap-1 text-sm text-muted">
          Ivory
          <span className="flex items-center gap-2">
            <span className="size-4 shrink-0 rounded-full bg-ivory ring-2 ring-brass" />
            <input
              value={names[0]}
              maxLength={18}
              onChange={(event) => onNames([event.target.value, names[1]])}
              className="h-12 w-full rounded-2xl border border-paper-deep bg-card px-3 text-base text-ink"
            />
          </span>
        </label>
        <label className="flex flex-col gap-1 text-sm text-muted">
          Oxblood
          <span className="flex items-center gap-2">
            <span className="size-4 shrink-0 rounded-full bg-oxblood" />
            <input
              value={names[1]}
              maxLength={18}
              onChange={(event) => onNames([names[0], event.target.value])}
              className="h-12 w-full rounded-2xl border border-paper-deep bg-card px-3 text-base text-ink"
            />
          </span>
        </label>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <Choice on={mode === "hotseat"} onClick={() => onMode("hotseat")}>
          Two people
        </Choice>
        <Choice on={mode === "cpu"} onClick={() => onMode("cpu")}>
          Versus computer
        </Choice>
      </div>
      {mode === "cpu" && (
        <div className="grid grid-cols-2 gap-2">
          <Choice on={human === 0} onClick={() => onHuman(0)}>
            You play ivory
          </Choice>
          <Choice on={human === 1} onClick={() => onHuman(1)}>
            You play oxblood
          </Choice>
        </div>
      )}

      <div className="mt-auto flex flex-col gap-2 pt-4">
        <button
          type="button"
          onClick={onToss}
          className="h-12 rounded-2xl bg-ochre text-base font-medium text-card"
        >
          Toss the coin
        </button>
        <button type="button" onClick={onRules} className="h-12 rounded-2xl text-sm text-muted">
          How to play
        </button>
      </div>
    </section>
  );
}

function Choice({ on, onClick, children }: { on: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`h-12 rounded-2xl text-sm font-medium ${on ? "bg-ink text-card" : "bg-card text-ink"}`}
    >
      {children}
    </button>
  );
}

function Toss({
  names,
  starter,
  onLanded,
  onBegin,
  onBack,
}: {
  names: [string, string];
  starter: Player | null;
  onLanded: (player: Player) => void;
  onBegin: () => void;
  onBack: () => void;
}) {
  const [spinning, setSpinning] = useState(false);
  const [landed, setLanded] = useState(false);
  const reduced =
    typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function toss() {
    if (spinning || landed) return;
    const who: Player = Math.random() < 0.5 ? 0 : 1;
    onLanded(who);
    play("toss");
    if (reduced) {
      setLanded(true);
      return;
    }
    setSpinning(true);
  }

  const end = starter === 1 ? "1980deg" : "1800deg";

  return (
    <section className="flex flex-1 flex-col items-center gap-6 pt-10">
      <div className="text-center">
        <h1 className="font-display text-4xl text-ink">The toss</h1>
        <p className="mt-2 text-sm text-muted">Ivory on one face, oxblood on the other.</p>
      </div>
      <button
        type="button"
        onClick={toss}
        disabled={spinning || landed}
        aria-label={landed ? "Coin has landed" : "Tap the coin to toss"}
        className="mt-4 disabled:cursor-default"
      >
        <span
          className={`coin-3d relative block size-32 ${spinning ? "is-spinning" : ""} ${reduced && starter === 1 ? "flipped" : ""}`}
          style={{ ["--spin-end" as string]: end }}
          onAnimationEnd={() => setLanded(true)}
        >
          <span className="coin-face absolute inset-0 grid place-items-center rounded-full border-4 border-brass bg-ivory font-display text-2xl text-ink">
            {names[0].slice(0, 1).toUpperCase() || "I"}
          </span>
          <span className="coin-face coin-back absolute inset-0 grid place-items-center rounded-full border-4 border-oxblood-deep bg-oxblood font-display text-2xl text-ivory">
            {names[1].slice(0, 1).toUpperCase() || "O"}
          </span>
        </span>
      </button>
      <p className="min-h-6 text-center text-base text-ink">
        {!starter && "Tap the coin."}
        {starter != null && !landed && "Spinning…"}
        {starter != null && landed && `${names[starter]} places first.`}
      </p>
      <div className="mt-auto flex w-full flex-col gap-2 pb-2">
        {landed && (
          <button
            type="button"
            onClick={onBegin}
            className="h-12 rounded-2xl bg-ochre text-base font-medium text-card"
          >
            Begin
          </button>
        )}
        <button type="button" onClick={onBack} className="h-12 text-sm text-muted">
          Back
        </button>
      </div>
    </section>
  );
}

function Rules({
  playing,
  onClose,
  onResign,
  onAbandon,
}: {
  playing: boolean;
  onClose: () => void;
  onResign: () => void;
  onAbandon: () => void;
}) {
  return (
    <div className="fixed inset-0 z-20 flex items-end justify-center bg-ink/40 p-3 sm:items-center">
      <article className="board-card max-h-[85dvh] w-full max-w-xl overflow-y-auto p-5">
        <h2 className="font-display text-3xl text-ink">How to play</h2>
        <div className="mt-3 flex flex-col gap-3 text-sm leading-relaxed text-ink">
          <p>Two players. Twelve coins each — ivory and oxblood. A coin toss decides who starts.</p>
          <p>
            Take turns placing a coin on an empty corner or crossing. When every coin is down, slide
            one of yours along a line to the next empty point.
          </p>
          <p>
            Three of your coins in a straight line is an isibhamu. You then remove one opposing coin.
            You may not take a coin that is itself in a line of three, unless every one of theirs is.
          </p>
          <p>
            The centre only finishes a line inside the small square — straight across or straight down
            through the middle. A line running out from the centre onto the next square does not count.
            Three along a square, or along an outer arm that does not touch the centre, does.
          </p>
          <p>With only three coins left on the board, you may jump to any empty point.</p>
          <p>You lose when only two of your coins are left on the board.</p>
          <p>
            If you cannot move, ask the other player to make way. They may shift one of their coins to
            open a path — that shift does not score a line — or they may take one of yours instead.
          </p>
          <p>The same position three times is a draw. Undo takes back the last move.</p>
        </div>
        <div className="mt-5 flex flex-col gap-2">
          {playing && (
            <button type="button" onClick={onResign} className="h-12 rounded-2xl bg-oxblood text-sm font-medium text-ivory">
              Resign this match
            </button>
          )}
          {playing && (
            <button type="button" onClick={onAbandon} className="h-12 rounded-2xl bg-card text-sm text-ink ring-1 ring-paper-deep">
              Abandon and go back
            </button>
          )}
          <button type="button" onClick={onClose} className="h-12 rounded-2xl bg-ink text-sm font-medium text-card">
            Close
          </button>
        </div>
      </article>
    </div>
  );
}
