import { EDGES, COORDS, POINT_LIST, type Board, type Player, type PointId } from "@/lib/umlabalaba/rules";

type Props = {
  board: Board;
  names: [string, string];
  selected: PointId | null;
  destinations: PointId[];
  removable: PointId[];
  mill: PointId[];
  lastPoint: PointId | null;
  interactive: boolean;
  onPoint: (id: PointId) => void;
};

function pieceFill(player: Player): string {
  return player === 0 ? "var(--color-ivory)" : "var(--color-oxblood)";
}

function pieceRim(player: Player): string {
  return player === 0 ? "var(--color-brass)" : "var(--color-oxblood-deep)";
}

export function BoardView({
  board,
  names,
  selected,
  destinations,
  removable,
  mill,
  lastPoint,
  interactive,
  onPoint,
}: Props) {
  const dest = new Set(destinations);
  const take = new Set(removable);
  const glow = new Set(mill);

  return (
    <svg
      viewBox="0 0 100 100"
      className="h-full w-full touch-manipulation select-none"
      role="group"
      aria-label="Umlabalaba board"
    >
      <defs>
        <filter id="cap-shadow" x="-50%" y="-50%" width="200%" height="200%">
          <feDropShadow dx="0" dy="0.45" stdDeviation="0.45" floodColor="#221e18" floodOpacity="0.28" />
        </filter>
      </defs>
      {EDGES.map(([a, b]) => (
        <line
          key={`${a}-${b}`}
          x1={COORDS[a].x}
          y1={COORDS[a].y}
          x2={COORDS[b].x}
          y2={COORDS[b].y}
          stroke="var(--color-line)"
          strokeWidth="0.85"
          strokeLinecap="round"
        />
      ))}
      {POINT_LIST.map((point) => {
        const owner = board[point.id];
        const isDest = dest.has(point.id);
        const isTake = take.has(point.id);
        const isSelected = selected === point.id;
        const isGlow = glow.has(point.id);
        const isLast = lastPoint === point.id;
        const label =
          owner == null
            ? "Empty point"
            : `${names[owner]} coin${isTake ? ", can be removed" : ""}`;
        return (
          <g
            key={point.id}
            role="button"
            tabIndex={interactive ? 0 : -1}
            aria-label={label}
            className={interactive ? "cursor-pointer" : undefined}
            onClick={() => interactive && onPoint(point.id)}
            onKeyDown={(event) => {
              if (!interactive) return;
              if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                onPoint(point.id);
              }
            }}
          >
            {isGlow && (
              <circle cx={point.x} cy={point.y} r="5.7" fill="var(--color-ochre)" opacity="0.28" />
            )}
            {isLast && owner != null && (
              <circle
                cx={point.x}
                cy={point.y}
                r="5.5"
                fill="none"
                stroke="var(--color-ink)"
                strokeOpacity="0.35"
                strokeWidth="0.45"
              />
            )}
            {isDest && (
              <circle
                cx={point.x}
                cy={point.y}
                r="3.15"
                fill="none"
                stroke="var(--color-ochre)"
                strokeWidth="0.7"
                className="dest-pulse"
              />
            )}
            {isTake && (
              <circle
                cx={point.x}
                cy={point.y}
                r="5.2"
                fill="none"
                stroke="var(--color-ochre)"
                strokeWidth="0.7"
                strokeDasharray="1.15 0.75"
                className="dest-pulse"
              />
            )}
            {owner == null ? (
              <circle cx={point.x} cy={point.y} r={isDest ? "1.25" : "1.35"} fill={isDest ? "var(--color-ochre)" : "var(--color-ink)"} />
            ) : (
              <g filter="url(#cap-shadow)">
                <circle cx={point.x} cy={point.y} r="4.15" fill={pieceRim(owner)} />
                <circle cx={point.x} cy={point.y} r="3.3" fill={pieceFill(owner)} />
                <circle
                  cx={point.x}
                  cy={point.y}
                  r="1.45"
                  fill="none"
                  stroke={pieceRim(owner)}
                  strokeWidth="0.45"
                />
              </g>
            )}
            {isSelected && (
              <circle
                cx={point.x}
                cy={point.y}
                r="5.35"
                fill="none"
                stroke="var(--color-ochre)"
                strokeWidth="0.75"
              />
            )}
            <circle cx={point.x} cy={point.y} r="6" fill="transparent" />
          </g>
        );
      })}
    </svg>
  );
}
