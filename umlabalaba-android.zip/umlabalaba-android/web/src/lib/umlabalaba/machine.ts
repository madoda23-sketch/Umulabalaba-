import {
  type Board,
  type Player,
  type PointId,
  type Shift,
  capturable,
  count,
  destinations,
  emptyBoard,
  hasAnyMove,
  hashPosition,
  isFlying,
  millsCompletedAt,
  movePiece,
  opponent,
  shiftMoves,
  withPoint,
  POINT_IDS,
  inMill,
} from "./rules.ts";

export type Mode = "hotseat" | "cpu";

export type Phase =
  | "ready"
  | "place"
  | "capture"
  | "move"
  | "stuck"
  | "respond"
  | "shift"
  | "take"
  | "over";

export type EventName = "place" | "slide" | "mill" | "take" | "win" | "draw" | "bad" | "ask";

type Stored = {
  board: Board;
  hand: [number, number];
  taken: [number, number];
  turn: Player;
  phase: Phase;
  after: Phase;
  gateActor: Player;
  gateText: string;
  selected: PointId | null;
  winner: Player | null;
  reason: string;
  millFlash: PointId[];
  lastPoint: PointId | null;
  mode: Mode;
  human: Player;
  names: [string, string];
  seen: Record<string, number>;
  log: string[];
  matchId: number;
};

export type Snapshot = { by: Player; state: Stored };

export type GameState = Stored & { history: Snapshot[] };

export type Action =
  | { type: "start"; starter: Player; mode: Mode; human: Player; names: [string, string]; matchId: number }
  | { type: "ready" }
  | { type: "place"; point: PointId }
  | { type: "capture"; point: PointId }
  | { type: "select"; point: PointId }
  | { type: "move"; from: PointId; to: PointId }
  | { type: "ask" }
  | { type: "want-shift" }
  | { type: "want-take" }
  | { type: "shift"; from: PointId; to: PointId }
  | { type: "take"; point: PointId }
  | { type: "undo" }
  | { type: "resign" };

export type ReduceResult = { state: GameState; events: EventName[] };

export function freshState(): GameState {
  return {
    board: emptyBoard(),
    hand: [12, 12],
    taken: [0, 0],
    turn: 0,
    phase: "place",
    after: "place",
    gateActor: 0,
    gateText: "",
    selected: null,
    winner: null,
    reason: "",
    millFlash: [],
    lastPoint: null,
    mode: "hotseat",
    human: 0,
    names: ["Ivory", "Oxblood"],
    seen: {},
    log: [],
    matchId: 0,
    history: [],
  };
}

export function activePlayer(state: GameState): Player {
  if (state.phase === "ready") return state.gateActor;
  if (state.phase === "respond" || state.phase === "shift" || state.phase === "take") {
    return opponent(state.turn);
  }
  return state.turn;
}

export function nameOf(state: GameState, player: Player): string {
  const raw = state.names[player]?.trim();
  return raw ? raw : player === 0 ? "Ivory" : "Oxblood";
}

function bad(state: GameState): ReduceResult {
  return { state, events: ["bad"] };
}

function snapshot(state: GameState, by: Player): Snapshot[] {
  const { history: _history, ...rest } = state;
  return [...state.history, { by, state: rest }];
}

function defeated(state: GameState, player: Player): boolean {
  return state.hand[player] === 0 && count(state.board, player) <= 2;
}

function victory(state: GameState, winner: Player, reason: string): ReduceResult {
  const log = pushLog(state, reason);
  return {
    state: {
      ...state,
      phase: "over",
      winner,
      reason,
      selected: null,
      log,
    },
    events: ["win"],
  };
}

function draw(state: GameState, reason: string): ReduceResult {
  return {
    state: {
      ...state,
      phase: "over",
      winner: null,
      reason,
      selected: null,
      log: pushLog(state, reason),
    },
    events: ["draw"],
  };
}

function pushLog(state: GameState, line: string): string[] {
  return [...state.log, line].slice(-16);
}

function gate(state: GameState, actor: Player, next: Phase, text: string): GameState {
  if (state.mode === "hotseat") {
    return {
      ...state,
      phase: "ready",
      after: next,
      gateActor: actor,
      gateText: text,
      selected: null,
    };
  }
  return { ...state, phase: next, after: next, gateActor: actor, gateText: text, selected: null };
}

function beginMove(state: GameState, player: Player): ReduceResult {
  if (defeated(state, player)) {
    return victory(state, opponent(player), `${nameOf(state, player)} has only two coins left.`);
  }
  const onBoard = count(state.board, player);
  const flying = isFlying(onBoard);
  if (!hasAnyMove(state.board, player, flying)) {
    const stuck: GameState = {
      ...state,
      turn: player,
      selected: null,
      log: pushLog(state, `${nameOf(state, player)} has nowhere to move.`),
    };
    return {
      state: gate(stuck, player, "stuck", `${nameOf(state, player)} cannot move.`),
      events: [],
    };
  }
  const hash = hashPosition(state.board, player);
  const seen = { ...state.seen, [hash]: (state.seen[hash] ?? 0) + 1 };
  if (seen[hash] >= 3) {
    return draw(
      { ...state, turn: player, seen },
      "This position has come up three times. The match is drawn.",
    );
  }
  const next: GameState = { ...state, turn: player, seen, selected: null };
  const text = flying
    ? `${nameOf(state, player)} has three coins and may jump.`
    : `${nameOf(state, player)} to move.`;
  return { state: gate(next, player, "move", text), events: [] };
}

function afterResolved(state: GameState): ReduceResult {
  const foe = opponent(state.turn);
  if (defeated(state, foe)) {
    return victory(state, state.turn, `${nameOf(state, foe)} has only two coins left.`);
  }
  if (defeated(state, state.turn)) {
    return victory(state, foe, `${nameOf(state, state.turn)} has only two coins left.`);
  }
  const placing = state.hand[0] > 0 || state.hand[1] > 0;
  if (placing) {
    const next = opponent(state.turn);
    const stepped: GameState = { ...state, turn: next, selected: null };
    return {
      state: gate(stepped, next, "place", `${nameOf(state, next)} places a coin.`),
      events: [],
    };
  }
  return beginMove(state, opponent(state.turn));
}

function unique(ids: PointId[]): PointId[] {
  return [...new Set(ids)];
}

export function reduce(state: GameState, action: Action): ReduceResult {
  switch (action.type) {
    case "start": {
      const names: [string, string] = [
        action.names[0].trim().slice(0, 18) || "Ivory",
        action.names[1].trim().slice(0, 18) || "Oxblood",
      ];
      const base = freshState();
      const started: GameState = {
        ...base,
        turn: action.starter,
        mode: action.mode,
        human: action.human,
        names,
        matchId: action.matchId,
        log: [`Coin toss: ${names[action.starter]} places first.`],
      };
      return {
        state: gate(started, action.starter, "place", `${names[action.starter]} places first.`),
        events: [],
      };
    }
    case "ready": {
      if (state.phase !== "ready") return bad(state);
      return { state: { ...state, phase: state.after, selected: null, millFlash: [] }, events: [] };
    }
    case "place": {
      if (state.phase !== "place") return bad(state);
      if (state.board[action.point] != null) return bad(state);
      if (state.hand[state.turn] <= 0) return bad(state);
      const history = snapshot(state, state.turn);
      const board = withPoint(state.board, action.point, state.turn);
      const hand: [number, number] = [state.hand[0], state.hand[1]];
      hand[state.turn] -= 1;
      const mills = millsCompletedAt(board, state.turn, action.point);
      const who = nameOf(state, state.turn);
      let next: GameState = {
        ...state,
        board,
        hand,
        history,
        lastPoint: action.point,
        selected: null,
        millFlash: [],
        log: pushLog(state, `${who} places a coin.`),
      };
      const foe = opponent(state.turn);
      if (mills.length > 0 && capturable(board, foe).length > 0) {
        next = {
          ...next,
          phase: "capture",
          millFlash: unique(mills.flat()),
          log: pushLog(next, `${who} makes a line of three.`),
        };
        return { state: next, events: ["place", "mill"] };
      }
      const fin = afterResolved(next);
      return { state: fin.state, events: ["place", ...fin.events] };
    }
    case "capture":
    case "take": {
      const taking = action.type === "take";
      if (taking ? state.phase !== "take" : state.phase !== "capture") return bad(state);
      const victim = state.turn;
      const actor = taking ? opponent(state.turn) : state.turn;
      if (!taking && state.board[action.point] !== opponent(state.turn)) return bad(state);
      if (taking && state.board[action.point] !== victim) return bad(state);
      if (!taking && !capturable(state.board, opponent(state.turn)).includes(action.point)) return bad(state);
      const history = taking ? snapshot(state, actor) : state.history;
      const board = withPoint(state.board, action.point, null);
      const taken: [number, number] = [state.taken[0], state.taken[1]];
      const removed = taking ? victim : opponent(state.turn);
      taken[removed] += 1;
      const who = nameOf(state, actor);
      const next: GameState = {
        ...state,
        board,
        taken,
        history,
        lastPoint: action.point,
        selected: null,
        millFlash: [],
        log: pushLog(state, `${who} removes a coin.`),
      };
      if (taking) {
        if (defeated(next, victim)) {
          const won = victory(next, opponent(victim), `${nameOf(next, victim)} has only two coins left.`);
          return { state: won.state, events: ["take", ...won.events] };
        }
        const onBoard = count(next.board, victim);
        const flying = isFlying(onBoard);
        if (!hasAnyMove(next.board, victim, flying)) {
          const stuck: GameState = {
            ...next,
            turn: victim,
            log: pushLog(next, `${nameOf(next, victim)} still cannot move.`),
          };
          return {
            state: gate(stuck, victim, "stuck", `${nameOf(next, victim)} still cannot move.`),
            events: ["take"],
          };
        }
        const moved = beginMove(next, victim);
        return { state: moved.state, events: ["take", ...moved.events] };
      }
      const fin = afterResolved(next);
      return { state: fin.state, events: ["take", ...fin.events] };
    }
    case "select": {
      if (state.phase !== "move" && state.phase !== "shift") return bad(state);
      const actor = activePlayer(state);
      if (state.board[action.point] !== actor) return bad(state);
      if (state.selected === action.point) {
        return { state: { ...state, selected: null }, events: [] };
      }
      const flying = state.phase === "move" && isFlying(count(state.board, actor));
      const dests =
        state.phase === "shift"
          ? shiftMoves(state.board, actor, state.turn)
              .filter((m) => m.from === action.point)
              .map((m) => m.to)
          : destinations(state.board, action.point, flying);
      if (dests.length === 0) return bad(state);
      return { state: { ...state, selected: action.point, millFlash: [] }, events: [] };
    }
    case "move": {
      if (state.phase !== "move") return bad(state);
      if (state.board[action.from] !== state.turn) return bad(state);
      const flying = isFlying(count(state.board, state.turn));
      if (!destinations(state.board, action.from, flying).includes(action.to)) return bad(state);
      const history = snapshot(state, state.turn);
      const board = movePiece(state.board, action.from, action.to);
      const mills = millsCompletedAt(board, state.turn, action.to);
      const who = nameOf(state, state.turn);
      let next: GameState = {
        ...state,
        board,
        history,
        lastPoint: action.to,
        selected: null,
        millFlash: [],
        log: pushLog(state, flying ? `${who} jumps.` : `${who} slides a coin.`),
      };
      const foe = opponent(state.turn);
      if (mills.length > 0 && capturable(board, foe).length > 0) {
        next = {
          ...next,
          phase: "capture",
          millFlash: unique(mills.flat()),
          log: pushLog(next, `${who} makes a line of three.`),
        };
        return { state: next, events: ["slide", "mill"] };
      }
      const fin = afterResolved(next);
      return { state: fin.state, events: ["slide", ...fin.events] };
    }
    case "ask": {
      if (state.phase !== "stuck") return bad(state);
      const foe = opponent(state.turn);
      const asked: GameState = {
        ...state,
        selected: null,
        log: pushLog(state, `${nameOf(state, state.turn)} asks ${nameOf(state, foe)} to make way.`),
      };
      return {
        state: gate(asked, foe, "respond", `${nameOf(state, foe)}, make way or take a coin.`),
        events: ["ask"],
      };
    }
    case "want-shift": {
      if (state.phase !== "respond") return bad(state);
      const foe = opponent(state.turn);
      if (shiftMoves(state.board, foe, state.turn).length === 0) return bad(state);
      return {
        state: { ...state, phase: "shift", selected: null, millFlash: [] },
        events: [],
      };
    }
    case "want-take": {
      if (state.phase !== "respond") return bad(state);
      return {
        state: { ...state, phase: "take", selected: null, millFlash: [] },
        events: [],
      };
    }
    case "shift": {
      if (state.phase !== "shift") return bad(state);
      const foe = opponent(state.turn);
      const legal = shiftMoves(state.board, foe, state.turn);
      if (!legal.some((m: Shift) => m.from === action.from && m.to === action.to)) return bad(state);
      const history = snapshot(state, foe);
      const board = movePiece(state.board, action.from, action.to);
      const next: GameState = {
        ...state,
        board,
        history,
        lastPoint: action.to,
        selected: null,
        millFlash: [],
        log: pushLog(state, `${nameOf(state, foe)} shifts a coin to make way.`),
      };
      const moved = beginMove(next, state.turn);
      return { state: moved.state, events: ["slide", ...moved.events] };
    }
    case "undo": {
      if (state.history.length === 0) return bad(state);
      if (state.mode === "cpu") {
        let idx = -1;
        for (let i = state.history.length - 1; i >= 0; i -= 1) {
          if (state.history[i].by === state.human) {
            idx = i;
            break;
          }
        }
        if (idx < 0) return bad(state);
        const snap = state.history[idx];
        return {
          state: { ...snap.state, history: state.history.slice(0, idx) },
          events: [],
        };
      }
      const history = state.history.slice(0, -1);
      const snap = state.history[state.history.length - 1];
      return { state: { ...snap.state, history }, events: [] };
    }
    case "resign": {
      if (state.phase === "over") return bad(state);
      const who = activePlayer(state);
      return victory(state, opponent(who), `${nameOf(state, who)} resigns.`);
    }
  }
}

export function hint(state: GameState): string {
  const me = nameOf(state, state.turn);
  const foe = nameOf(state, opponent(state.turn));
  switch (state.phase) {
    case "ready":
      return state.gateText;
    case "place":
      return `${nameOf(state, state.turn)} places a coin. ${state.hand[state.turn]} still in hand.`;
    case "capture": {
      const foePlayer = opponent(state.turn);
      const allInLines =
        count(state.board, foePlayer) > 0 &&
        POINT_IDS.filter((id) => state.board[id] === foePlayer).every((id) => inMill(state.board, id));
      return allInLines
        ? `Line of three. Every ${foe} coin is already in a line — take any.`
        : `Line of three. ${me}, take a ${foe} coin that is not sitting in a line.`;
    }
    case "move":
      return isFlying(count(state.board, state.turn))
        ? `${me} has three coins and may jump to any empty point.`
        : `${me}, slide a coin along a line to the next empty point.`;
    case "stuck":
      return `${me} cannot move. Ask ${foe} to make way.`;
    case "respond":
      return `${me} is stuck. ${foe}, shift a coin to open a path, or take one of theirs.`;
    case "shift":
      return `${foe}, move one of your coins off a point beside ${me}. This does not score a line.`;
    case "take":
      return `${foe}, tap one of ${me}'s coins to remove it.`;
    case "over":
      return state.reason;
    default:
      return "";
  }
}

export function legalDestinations(state: GameState): PointId[] {
  if (!state.selected) return [];
  if (state.phase === "move") {
    return destinations(state.board, state.selected, isFlying(count(state.board, state.turn)));
  }
  if (state.phase === "shift") {
    const foe = opponent(state.turn);
    return shiftMoves(state.board, foe, state.turn)
      .filter((m) => m.from === state.selected)
      .map((m) => m.to);
  }
  return [];
}

export function removablePoints(state: GameState): PointId[] {
  if (state.phase === "capture") return capturable(state.board, opponent(state.turn));
  if (state.phase === "take") return POINT_IDS.filter((id) => state.board[id] === state.turn);
  return [];
}
