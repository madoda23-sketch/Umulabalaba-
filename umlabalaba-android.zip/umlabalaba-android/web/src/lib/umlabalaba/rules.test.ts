import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { chooseAiAction } from "./ai.ts";
import { freshState, reduce, type GameState } from "./machine.ts";
import {
  EDGES,
  MILLS,
  POINT_IDS,
  capturable,
  destinations,
  emptyBoard,
  hasAnyMove,
  millsCompletedAt,
  neighbors,
  shiftMoves,
  withPoint,
  type Player,
  type PointId,
} from "./rules.ts";

function ready(state: GameState): GameState {
  if (state.phase !== "ready") return state;
  return reduce(state, { type: "ready" }).state;
}

function place(state: GameState, point: PointId): GameState {
  const stepped = ready(state);
  const result = reduce(stepped, { type: "place", point });
  assert.equal(result.events.includes("bad"), false, `place ${point} in ${stepped.phase}`);
  return result.state;
}

describe("board", () => {
  it("has the 25 points from the sketch", () => {
    assert.equal(POINT_IDS.length, 25);
    assert.equal(new Set(POINT_IDS).size, 25);
  });

  it("joins every line in both directions", () => {
    for (const [a, b] of EDGES) {
      assert.ok(neighbors(a).includes(b));
      assert.ok(neighbors(b).includes(a));
      assert.notEqual(a, b);
    }
  });

  it("only counts lines that are really three connected points", () => {
    for (const [a, b, c] of MILLS) {
      assert.ok(neighbors(a).includes(b), `${a}-${b}`);
      assert.ok(neighbors(b).includes(c), `${b}-${c}`);
    }
  });

  it("does not count a line running out from the centre", () => {
    const banned = [
      ["mT", "iT", "c"],
      ["c", "iB", "mB"],
      ["mL", "iL", "c"],
      ["c", "iR", "mR"],
    ];
    for (const mill of banned) {
      assert.equal(
        MILLS.some((line) => line.every((id) => mill.includes(id))),
        false,
        mill.join("-"),
      );
    }
  });
});

describe("play", () => {
  it("will not take a coin that already sits in a line", () => {
    let state = reduce(freshState(), {
      type: "start",
      starter: 0,
      mode: "cpu",
      human: 0,
      names: ["Ivory", "Oxblood"],
      matchId: 1,
    }).state;
    const board = emptyBoard();
    board.oTL = 0;
    board.oT = 0;
    board.oTR = 0;
    board.oBL = 1;
    board.oB = 1;
    board.oBR = 1;
    board.mR = 1;
    state = { ...state, phase: "capture", turn: 0, board, hand: [9, 9] };
    const caps = capturable(state.board, 1);
    assert.deepEqual(caps, ["mR"]);
    const refused = reduce(state, { type: "capture", point: "oB" });
    assert.equal(refused.events.includes("bad"), true);
    const taken = reduce(state, { type: "capture", point: "mR" });
    assert.equal(taken.events.includes("bad"), false);
    assert.equal(taken.state.board.mR, null);
    assert.equal(taken.state.board.oB, 1);
  });

  it("lets the centre finish a line only inside the small square", () => {
    const board = emptyBoard();
    board.iT = 0;
    board.c = 0;
    board.iB = 0;
    assert.equal(millsCompletedAt(board, 0, "c").length, 1);

    const outward = emptyBoard();
    outward.mT = 0;
    outward.iT = 0;
    outward.c = 0;
    assert.equal(millsCompletedAt(outward, 0, "c").length, 0);
    assert.equal(millsCompletedAt(outward, 0, "iT").length, 0);
  });

  it("flies at three coins and loses at two", () => {
    let state = reduce(freshState(), {
      type: "start",
      starter: 0,
      mode: "cpu",
      human: 0,
      names: ["Ivory", "Oxblood"],
      matchId: 2,
    }).state;
    state = {
      ...state,
      phase: "move",
      hand: [0, 0],
      board: withPoint(withPoint(withPoint(emptyBoard(), "oTL", 0), "oT", 0), "oTR", 0),
    };
    state.board.oBL = 1;
    state.board.oB = 1;
    state.board.oBR = 1;
    state.board.mB = 1;
    assert.deepEqual(destinations(state.board, "oTL", true).includes("c"), true);
    assert.equal(hasAnyMove(state.board, 0, false), true);

    state = reduce(state, { type: "move", from: "oT", to: "c" }).state;
    assert.notEqual(state.phase, "over");

    state = {
      ...ready(state),
      phase: "move",
      turn: 1,
      board: { ...state.board, oB: null },
    };
    const lost = reduce(state, { type: "move", from: "oBL", to: "oB" }).state;
    if (lost.phase === "capture") {
      const victim = capturable(lost.board, 0)[0];
      const after = reduce(lost, { type: "capture", point: victim }).state;
      assert.equal(after.phase, "over");
      assert.equal(after.winner, 1);
    }
  });

  it("only shifts a coin that opens a path", () => {
    const board = emptyBoard();
    board.oTL = 0;
    board.oT = 1;
    board.oL = 1;
    board.mTL = 0;
    board.mT = 0;
    board.mL = 0;
    const shifts = shiftMoves(board, 1, 0);
    assert.ok(shifts.length > 0);
    assert.ok(shifts.every((move) => move.from === "oT" || move.from === "oL"));
  });

  it("plays legal games through to a result", () => {
    for (let n = 0; n < 20; n += 1) {
      let state = reduce(freshState(), {
        type: "start",
        starter: n % 2 === 0 ? 0 : 1,
        mode: "hotseat",
        human: 0,
        names: ["Ivory", "Oxblood"],
        matchId: n + 3,
      }).state;
      for (let step = 0; step < 1500 && state.phase !== "over"; step += 1) {
        const action = legal(state);
        assert.ok(action, `no legal action in ${state.phase}`);
        const result = reduce(state, action);
        assert.equal(result.events.includes("bad"), false, `${state.phase} ${action.type}`);
        state = result.state;
      }
      assert.equal(state.phase, "over");
    }
  });

  it("the computer always offers a legal reply", () => {
    let state = reduce(freshState(), {
      type: "start",
      starter: 1,
      mode: "cpu",
      human: 0,
      names: ["Ivory", "Oxblood"],
      matchId: 50,
    }).state;
    for (let step = 0; step < 40 && state.phase !== "over"; step += 1) {
      if (active(state) === 0) {
        const action = legal(state);
        assert.ok(action);
        state = reduce(state, action).state;
      } else {
        const action = chooseAiAction(state);
        assert.ok(action, state.phase);
        const result = reduce(state, action);
        assert.equal(result.events.includes("bad"), false, action.type);
        state = result.state;
      }
    }
  });
});

function active(state: GameState): Player {
  if (state.phase === "respond" || state.phase === "shift" || state.phase === "take") {
    return state.turn === 0 ? 1 : 0;
  }
  if (state.phase === "ready") return state.gateActor;
  return state.turn;
}

function legal(state: GameState) {
  if (state.phase === "ready") return { type: "ready" as const };
  if (state.phase === "place") {
    const empties = POINT_IDS.filter((id) => state.board[id] == null);
    return { type: "place" as const, point: empties[Math.floor(Math.random() * empties.length)] };
  }
  if (state.phase === "capture") {
    const caps = capturable(state.board, state.turn === 0 ? 1 : 0);
    return { type: "capture" as const, point: caps[Math.floor(Math.random() * caps.length)] };
  }
  if (state.phase === "take") {
    const caps = POINT_IDS.filter((id) => state.board[id] === state.turn);
    return { type: "take" as const, point: caps[Math.floor(Math.random() * caps.length)] };
  }
  if (state.phase === "stuck") return { type: "ask" as const };
  if (state.phase === "respond") return { type: "want-take" as const };
  if (state.phase === "shift") {
    const foe: Player = state.turn === 0 ? 1 : 0;
    const moves = shiftMoves(state.board, foe, state.turn);
    const move = moves[Math.floor(Math.random() * moves.length)];
    return { type: "shift" as const, from: move.from, to: move.to };
  }
  if (state.phase === "move") {
    const flying = countOwned(state, state.turn) === 3;
    const options: { from: PointId; to: PointId }[] = [];
    for (const from of POINT_IDS) {
      if (state.board[from] !== state.turn) continue;
      for (const to of destinations(state.board, from, flying)) options.push({ from, to });
    }
    const move = options[Math.floor(Math.random() * options.length)];
    return { type: "move" as const, from: move.from, to: move.to };
  }
  return null;
}

function countOwned(state: GameState, player: Player): number {
  return POINT_IDS.filter((id) => state.board[id] === player).length;
}
