export type SoundName = "place" | "slide" | "mill" | "take" | "win" | "draw" | "bad" | "ask" | "toss";

let ctx: AudioContext | null = null;
let muted = false;

export function setMuted(next: boolean) {
  muted = next;
}

export function isMuted() {
  return muted;
}

export function unlockAudio() {
  const audio = context();
  if (audio.state === "suspended") void audio.resume();
}

function context(): AudioContext {
  if (!ctx) ctx = new AudioContext();
  return ctx;
}

function tone(freq: number, at: number, dur: number, gain: number, type: OscillatorType = "sine") {
  const audio = context();
  const osc = audio.createOscillator();
  const amp = audio.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, at);
  amp.gain.setValueAtTime(0.0001, at);
  amp.gain.exponentialRampToValueAtTime(gain, at + 0.015);
  amp.gain.exponentialRampToValueAtTime(0.0001, at + dur);
  osc.connect(amp);
  amp.connect(audio.destination);
  osc.start(at);
  osc.stop(at + dur + 0.02);
}

export function play(name: SoundName) {
  if (muted || typeof window === "undefined") return;
  try {
    const audio = context();
    if (audio.state === "suspended") void audio.resume();
    const now = audio.currentTime;
    switch (name) {
      case "place":
        tone(540, now, 0.09, 0.035);
        break;
      case "slide":
        tone(420, now, 0.08, 0.03);
        tone(560, now + 0.05, 0.08, 0.025);
        break;
      case "mill":
        tone(660, now, 0.1, 0.04);
        tone(880, now + 0.09, 0.14, 0.04);
        break;
      case "take":
        tone(196, now, 0.16, 0.045, "triangle");
        break;
      case "ask":
        tone(330, now, 0.08, 0.025);
        break;
      case "toss":
        tone(700, now, 0.06, 0.03, "triangle");
        tone(480, now + 0.07, 0.1, 0.03, "triangle");
        break;
      case "bad":
        tone(140, now, 0.08, 0.03, "square");
        break;
      case "draw":
        tone(392, now, 0.12, 0.03);
        tone(330, now + 0.12, 0.16, 0.03);
        break;
      case "win":
        tone(523, now, 0.12, 0.04);
        tone(659, now + 0.1, 0.12, 0.04);
        tone(784, now + 0.2, 0.2, 0.045);
        break;
      default:
        break;
    }
  } catch {
    /* audio is optional */
  }
}
