export type Player = 0 | 1;

export const POINT_LIST = [
  { id: "oTL", x: 8, y: 8 },
  { id: "oT", x: 50, y: 8 },
  { id: "oTR", x: 92, y: 8 },
  { id: "oR", x: 92, y: 50 },
  { id: "oBR", x: 92, y: 92 },
  { id: "oB", x: 50, y: 92 },
  { id: "oBL", x: 8, y: 92 },
  { id: "oL", x: 8, y: 50 },
  { id: "mTL", x: 26, y: 26 },
  { id: "mT", x: 50, y: 26 },
  { id: "mTR", x: 74, y: 26 },
  { id: "mR", x: 74, y: 50 },
  { id: "mBR", x: 74, y: 74 },
  { id: "mB", x: 50, y: 74 },
  { id: "mBL", x: 26, y: 74 },
  { id: "mL", x: 26, y: 50 },
  { id: "iTL", x: 38, y: 38 },
  { id: "iT", x: 50, y: 38 },
  { id: "iTR", x: 62, y: 38 },
  { id: "iR", x: 62, y: 50 },
  { id: "iBR", x: 62, y: 62 },
  { id: "iB", x: 50, y: 62 },
  { id: "iBL", x: 38, y: 62 },
  { id: "iL", x: 38, y: 50 },
  { id: "c", x: 50, y: 50 },
] as const;

export type PointId = (typeof POINT_LIST)[number]["id"];

export const POINT_IDS: PointId[] = POINT_LIST.map((p) => p.id);

export const COORDS: Record<PointId, { x: number; y: number }> = Object.fromEntries(
  POINT_LIST.map((p) => [p.id, { x: p.x, y: p.y }]),
) as Record<PointId, { x: number; y: number }>;

/** Lines a coin may slide along. Diagonals stop at the middle square. */
export const EDGES: [PointId, PointId][] = [
  ["oTL", "oT"],
  ["oT", "oTR"],
  ["oTR", "oR"],
  ["oR", "oBR"],
  ["oBR", "oB"],
  ["oB", "oBL"],
  ["oBL", "oL"],
  ["oL", "oTL"],
  ["mTL", "mT"],
  ["mT", "mTR"],
  ["mTR", "mR"],
  ["mR", "mBR"],
  ["mBR", "mB"],
  ["mB", "mBL"],
  ["mBL", "mL"],
  ["mL", "mTL"],
  ["iTL", "iT"],
  ["iT", "iTR"],
  ["iTR", "iR"],
  ["iR", "iBR"],
  ["iBR", "iB"],
  ["iB", "iBL"],
  ["iBL", "iL"],
  ["iL", "iTL"],
  ["oT", "mT"],
  ["mT", "iT"],
  ["iT", "c"],
  ["c", "iB"],
  ["iB", "mB"],
  ["mB", "oB"],
  ["oL", "mL"],
  ["mL", "iL"],
  ["iL", "c"],
  ["c", "iR"],
  ["iR", "mR"],
  ["mR", "oR"],
  ["oTL", "mTL"],
  ["oTR", "mTR"],
  ["oBR", "mBR"],
  ["oBL", "mBL"],
];

const NEIGHBORS: Record<PointId, PointId[]> = Object.fromEntries(
  POINT_IDS.map((id) => [id, [] as PointId[]]),
) as Record<PointId, PointId[]>;

for (const [a, b] of EDGES) {
  NEIGHBORS[a].push(b);
  NEIGHBORS[b].push(a);
}

export function neighbors(id: PointId): PointId[] {
  return NEIGHBORS[id];
}

/**
 * Threes that count as an isibhamu.
 * The centre only completes a line inside the small square.
 * A line that runs out from the centre onto the next square does not count,
 * so [mT, iT, c] and its mirrors are deliberately absent.
 * Threes on the spokes that do not touch the centre still count.
 */
export const MILLS: [PointId, PointId, PointId][] = [
  ["oTL", "oT", "oTR"],
  ["oTR", "oR", "oBR"],
  ["oBR", "oB", "oBL"],
  ["oBL", "oL", "oTL"],
  ["mTL", "mT", "mTR"],
  ["mTR", "mR", "mBR"],
  ["mBR", "mB", "mBL"],
  ["mBL", "mL", "mTL"],
  ["iTL", "iT", "iTR"],
  ["iTR", "iR", "iBR"],
  ["iBR", "iB", "iBL"],
  ["iBL", "iL", "iTL"],
  ["iT", "c", "iB"],
  ["iL", "c", "iR"],
  ["oT", "mT", "iT"],
  ["iB", "mB", "oB"],
  ["oL", "mL", "iL"],
  ["iR", "mR", "oR"],
];

export type Board = Record<PointId, Player | null>;

export function emptyBoard(): Board {
  return Object.fromEntries(POINT_IDS.map((id) => [id, null])) as Board;
}

export function opponent(player: Player): Player {
  return player === 0 ? 1 : 0;
}

export function count(board: Board, player: Player): number {
  let n = 0;
  for (const id of POINT_IDS) if (board[id] === player) n += 1;
  return n;
}

export function millsCompletedAt(board: Board, player: Player, at: PointId): [PointId, PointId, PointId][] {
  return MILLS.filter((mill) => mill.includes(at) && mill.every((p) => board[p] === player));
}

export function inMill(board: Board, id: PointId): boolean {
  const player = board[id];
  if (player == null) return false;
  return millsCompletedAt(board, player, id).length > 0;
}

/** Coins that may be removed. A coin in a line is safe unless every opposing coin is. */
export function capturable(board: Board, victim: Player): PointId[] {
  const theirs = POINT_IDS.filter((id) => board[id] === victim);
  const loose = theirs.filter((id) => !inMill(board, id));
  return loose.length > 0 ? loose : theirs;
}

export function isFlying(onBoard: number): boolean {
  return onBoard === 3;
}

export function destinations(board: Board, from: PointId, flying: boolean): PointId[] {
  if (flying) return POINT_IDS.filter((id) => board[id] == null);
  return neighbors(from).filter((id) => board[id] == null);
}

export function hasAnyMove(board: Board, player: Player, flying: boolean): boolean {
  if (flying) return POINT_IDS.some((id) => board[id] == null);
  return POINT_IDS.some(
    (id) => board[id] === player && neighbors(id).some((n) => board[n] == null),
  );
}

export function withPoint(board: Board, id: PointId, value: Player | null): Board {
  return { ...board, [id]: value };
}

export function movePiece(board: Board, from: PointId, to: PointId): Board {
  const player = board[from];
  return { ...board, [from]: null, [to]: player };
}

export type Shift = { from: PointId; to: PointId };

/**
 * A courtesy move: the responder slides one coin to the next empty point,
 * and the point they leave must sit beside one of the stuck player's coins.
 */
export function shiftMoves(board: Board, responder: Player, stuck: Player): Shift[] {
  const moves: Shift[] = [];
  for (const from of POINT_IDS) {
    if (board[from] !== responder) continue;
    const opens = neighbors(from).some((n) => board[n] === stuck);
    if (!opens) continue;
    for (const to of neighbors(from)) {
      if (board[to] != null) continue;
      moves.push({ from, to });
    }
  }
  const quiet = moves.filter((m) => {
    const next = movePiece(board, m.from, m.to);
    return millsCompletedAt(next, responder, m.to).length === 0;
  });
  return quiet.length > 0 ? quiet : moves;
}

export function hashPosition(board: Board, turn: Player): string {
  let s = turn === 0 ? "0" : "1";
  for (const id of POINT_IDS) {
    const v = board[id];
    s += v == null ? "." : v === 0 ? "a" : "b";
  }
  return s;
}
