import type { Action, GameState } from "./machine.ts";
import { activePlayer } from "./machine.ts";
import {
  type Player,
  type PointId,
  MILLS,
  POINT_IDS,
  capturable,
  count,
  destinations,
  inMill,
  isFlying,
  millsCompletedAt,
  movePiece,
  neighbors,
  opponent,
  shiftMoves,
  withPoint,
} from "./rules.ts";

function threatPoints(board: GameState["board"], player: Player): Set<PointId> {
  const spots = new Set<PointId>();
  for (const mill of MILLS) {
    let mine = 0;
    let empty: PointId | null = null;
    let blanks = 0;
    for (const id of mill) {
      if (board[id] === player) mine += 1;
      else if (board[id] == null) {
        blanks += 1;
        empty = id;
      }
    }
    if (mine === 2 && blanks === 1 && empty) spots.add(empty);
  }
  return spots;
}

function pieceValue(board: GameState["board"], player: Player, id: PointId): number {
  let value = 6 + neighbors(id).filter((n) => board[n] == null).length;
  for (const mill of MILLS) {
    if (!mill.includes(id)) continue;
    let mine = 0;
    let blanks = 0;
    for (const p of mill) {
      if (board[p] === player) mine += 1;
      else if (board[p] == null) blanks += 1;
    }
    if (mine === 2 && blanks === 1) value += 30;
    else if (mine === 1 && blanks === 2) value += 4;
  }
  return value;
}

function bestCaptureValue(board: GameState["board"], victim: Player): number {
  const caps = capturable(board, victim);
  if (caps.length === 0) return 0;
  let best = 0;
  for (const id of caps) best = Math.max(best, pieceValue(board, victim, id));
  return best;
}

function buildScore(board: GameState["board"], player: Player, at: PointId): number {
  let score = 0;
  for (const mill of MILLS) {
    if (!mill.includes(at)) continue;
    let mine = 0;
    let blanks = 0;
    for (const id of mill) {
      if (id === at) continue;
      if (board[id] === player) mine += 1;
      else if (board[id] == null) blanks += 1;
    }
    if (mine === 1 && blanks === 1) score += 1;
  }
  return score;
}

function placeScore(state: GameState, point: PointId): number {
  const me = state.turn;
  const foe = opponent(me);
  let score = Math.random() * 0.35;
  if (threatPoints(state.board, foe).has(point)) score += 72;
  const board = withPoint(state.board, point, me);
  const mills = millsCompletedAt(board, me, point);
  if (mills.length > 0) score += 110 + bestCaptureValue(board, foe);
  else score += buildScore(state.board, me, point) * 9;
  if (point === "c") score += 4;
  else if (point.startsWith("i")) score += 1;
  const before = threatPoints(state.board, foe);
  let fresh = 0;
  for (const spot of threatPoints(board, foe)) if (!before.has(spot)) fresh += 1;
  if (mills.length === 0) score -= fresh * 14;
  return score;
}

function moveScore(state: GameState, from: PointId, to: PointId): number {
  const me = state.turn;
  const foe = opponent(me);
  let score = Math.random() * 0.35;
  if (threatPoints(state.board, foe).has(to)) score += 58;
  const board = movePiece(state.board, from, to);
  const mills = millsCompletedAt(board, me, to);
  if (mills.length > 0) score += 120 + bestCaptureValue(board, foe);
  else score += buildScore(board, me, to) * 7;
  if (inMill(state.board, from) && mills.length === 0) score -= 10;
  const before = threatPoints(state.board, foe);
  if (mills.length === 0) {
    let fresh = 0;
    for (const spot of threatPoints(board, foe)) if (!before.has(spot)) fresh += 1;
    score -= fresh * 28;
  }
  return score;
}

function bestPoint(ids: PointId[], scoreOf: (id: PointId) => number): PointId {
  let best = ids[0];
  let bestScore = -Infinity;
  for (const id of ids) {
    const score = scoreOf(id);
    if (score > bestScore) {
      best = id;
      bestScore = score;
    }
  }
  return best;
}

export function chooseAiAction(state: GameState): Action | null {
  if (state.mode !== "cpu") return null;
  if (activePlayer(state) === state.human) return null;
  switch (state.phase) {
    case "place": {
      const empties = POINT_IDS.filter((id) => state.board[id] == null);
      if (empties.length === 0) return null;
      return { type: "place", point: bestPoint(empties, (id) => placeScore(state, id)) };
    }
    case "capture": {
      const caps = capturable(state.board, opponent(state.turn));
      if (caps.length === 0) return null;
      return {
        type: "capture",
        point: bestPoint(caps, (id) => pieceValue(state.board, opponent(state.turn), id)),
      };
    }
    case "move": {
      const flying = isFlying(count(state.board, state.turn));
      let best: { from: PointId; to: PointId } | null = null;
      let bestScore = -Infinity;
      for (const from of POINT_IDS) {
        if (state.board[from] !== state.turn) continue;
        for (const to of destinations(state.board, from, flying)) {
          const score = moveScore(state, from, to);
          if (score > bestScore) {
            best = { from, to };
            bestScore = score;
          }
        }
      }
      return best ? { type: "move", from: best.from, to: best.to } : { type: "ask" };
    }
    case "stuck":
      return { type: "ask" };
    case "respond": {
      const foe = opponent(state.turn);
      const shifts = shiftMoves(state.board, foe, state.turn);
      const stuckCount = count(state.board, state.turn);
      if (shifts.length > 0 && stuckCount >= 6) return { type: "want-shift" };
      return { type: "want-take" };
    }
    case "shift": {
      const foe = opponent(state.turn);
      const shifts = shiftMoves(state.board, foe, state.turn);
      if (shifts.length === 0) return { type: "want-take" };
      const ranked = [...shifts].sort((a, b) => {
        const am = inMill(state.board, a.from) ? 1 : 0;
        const bm = inMill(state.board, b.from) ? 1 : 0;
        return am - bm;
      });
      const pool = ranked.slice(0, Math.min(3, ranked.length));
      const pick = pool[Math.floor(Math.random() * pool.length)];
      return { type: "shift", from: pick.from, to: pick.to };
    }
    case "take": {
      const caps = POINT_IDS.filter((id) => state.board[id] === state.turn);
      if (caps.length === 0) return null;
      return {
        type: "take",
        point: bestPoint(caps, (id) => pieceValue(state.board, state.turn, id)),
      };
    }
    default:
      return null;
  }
}
