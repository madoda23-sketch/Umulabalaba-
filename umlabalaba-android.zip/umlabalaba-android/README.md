# Umlabalaba – Android APK

The game is fully offline (no server needed), wrapped with Capacitor.

## Easiest: build the APK on GitHub (no Android Studio)
1. Create a new GitHub repo and push this folder to `main`.
2. Open the **Actions** tab → *Build Android APK* (runs automatically on push).
3. When it finishes, download the **umlabalaba-debug-apk** artifact → unzip → `app-debug.apk`.
4. Copy it to your phone, open it, allow "Install unknown apps" when asked.

## Build locally
Needs Node 20+, JDK 21 and the Android SDK (Android Studio installs it).
```
npm install
npm run android:init     # first time only: creates android/, icons, portrait lock
npm run android:apk      # -> android/app/build/outputs/apk/debug/app-debug.apk
```
After changing game code: `npm run android:apk` again.

## Notes
- Debug APK is fine for sideloading. For Google Play you need a signed release
  AAB (`./gradlew bundleRelease` + your own keystore).
- App id: `co.za.sisonke.umlabalaba` (change in `capacitor.config.json` before first release).
- Web fonts load from Google Fonts when online; offline it falls back to system fonts.
- Game source is in `web/src`; the multiplayer/auth/server code from the original
  workspace was unused by the game and left out.
