// Bundles the game into ./www (what Capacitor ships inside the APK).
import { build } from "esbuild";
import { compile } from "tailwindcss";
import { readFileSync, writeFileSync, mkdirSync, rmSync, cpSync, readdirSync, statSync } from "node:fs";
import { createRequire } from "node:module";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const web = join(root, "web");
const out = join(root, "www");
const require = createRequire(join(root, "package.json"));

rmSync(out, { recursive: true, force: true });
mkdirSync(out, { recursive: true });

// 1. JS
await build({
  entryPoints: [join(web, "src/main.tsx")],
  bundle: true,
  minify: true,
  format: "iife",
  target: ["chrome90"],
  outfile: join(out, "app.js"),
  alias: { "@": join(web, "src") },
  jsx: "automatic",
  define: { "process.env.NODE_ENV": '"production"' },
  logLevel: "info",
});

// 2. CSS (Tailwind v4 via its programmatic API)
function walk(dir, acc = []) {
  for (const f of readdirSync(dir)) {
    const p = join(dir, f);
    statSync(p).isDirectory() ? walk(p, acc) : /\.(tsx?|html)$/.test(f) && acc.push(p);
  }
  return acc;
}
const candidates = new Set();
for (const f of [...walk(join(web, "src")), join(web, "index.html")]) {
  for (const m of readFileSync(f, "utf8").matchAll(/[^\s"'`<>{}()=,;]+/g)) candidates.add(m[0]);
}
const css = readFileSync(join(web, "src/styles.css"), "utf8");
const compiler = await compile(css, {
  base: join(web, "src"),
  loadStylesheet: async (id, base) => {
    const path = id === "tailwindcss" ? require.resolve("tailwindcss/index.css") : resolve(base, id);
    return { path, base: dirname(path), content: readFileSync(path, "utf8") };
  },
});
writeFileSync(join(out, "app.css"), compiler.build([...candidates]));

// 3. Static files
cpSync(join(web, "index.html"), join(out, "index.html"));
cpSync(join(web, "favicon.svg"), join(out, "favicon.svg"));
console.log("Web build written to", out);
