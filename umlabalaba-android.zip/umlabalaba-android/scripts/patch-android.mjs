// Run once after `cap add android`: portrait lock + paper-coloured status bar.
import { readFileSync, writeFileSync, existsSync } from "node:fs";
const manifest = "android/app/src/main/AndroidManifest.xml";
if (existsSync(manifest)) {
  let x = readFileSync(manifest, "utf8");
  if (!x.includes("screenOrientation")) x = x.replace("<activity", '<activity\n            android:screenOrientation="portrait"');
  writeFileSync(manifest, x);
  console.log("Patched", manifest);
}
